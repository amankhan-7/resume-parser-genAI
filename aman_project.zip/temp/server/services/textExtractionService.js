const pdf = require('pdf-parse');

const extractTextFromPDF = async (dataBuffer) => {
    try {
        const data = await pdf(dataBuffer);
        return data.text;
    } catch (error) {
        console.log("Error occured in textExtractionService", error);
        throw error;
    }
};

module.exports = { extractTextFromPDF };
