import './Home.css'
import { useContext } from 'react'
import GlobalStore from '../../contexts/GlobalStore/GlobalStore'
import LoadingSpinner from '../LoadingSpinner/LoadingSpinner';

export default function Home() {

    const globalStore = useContext(GlobalStore);
    const { inputFile, setInputFile, serverRes, parsePdf, loading, setLoading } = globalStore;

    const handleFileUpload = (event) => {
        setInputFile(event.target.files[0])
    }

    const handleParseBtn = () => {
        console.log("inputFile: ", inputFile);
        setLoading(true);
        parsePdf();
    }

    return (
        <div className='container'>
            <div className='io-container'>
                <div className="input-container">
                    <input type="file" accept='application/pdf' name='inputFile' onChange={handleFileUpload} />
                    <button className='parse-btn' onClick={handleParseBtn} disabled={inputFile ? false : true}>Parse</button>
                </div>
                <pre className='result-section'>
                    {loading ? <LoadingSpinner /> : serverRes}
                </pre>
            </div>
        </div>
    )
}
