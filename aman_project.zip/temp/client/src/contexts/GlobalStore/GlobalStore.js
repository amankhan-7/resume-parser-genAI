import { createContext } from "react";

const GlobalStore = createContext();

export default GlobalStore;